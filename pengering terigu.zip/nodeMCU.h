#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>

WiFiClient client;

//class nodeMCU
class nodeMCU
{
  public:
  void   connecting(char* _ssid,char* _password );
  void sentData(String key,String data1, String data2,String data3);
};

//method
void nodeMCU::connecting(char* _ssid,char* _password )
{ 
  WiFi.begin(_ssid, _password);
  Serial.println();
  Serial.print("Connecting"); 
  while (WiFi.status() != WL_CONNECTED) 
  {
        delay(500);
        Serial.print(".");
  }
  
  Serial.println("");
  Serial.println("success");
  Serial.print("IP Address is: ");
  Serial.println(WiFi.localIP());
}

void nodeMCU::sentData(String key,String data1, String data2,String data3) 
{
  if (WiFi.status() == WL_CONNECTED) 
  { 
    //Check WiFi connection status
     
    HTTPClient http;  //Declare an object of class HTTPClient
    String url = "http://api.thingspeak.com/update?api_key="; //&field1=0
            
    String GET_STR = url + key + "&field1=" + data1 + "&field2=" + data2 + "&field4=" + data3;
   // Serial.print(GET_STR.c_str());
    http.begin(GET_STR.c_str());  //Specify request destination
    int httpCode = http.GET();
                                                                      
    //Send the request     
    if (httpCode > 0) 
    { 
      //Check the returning code          
      String payload = http.getString();   //Get the request response payload
      //Serial.println(payload);                     //Print the response payload     
    }
    
    http.end();   //Close connection          
  }
}
