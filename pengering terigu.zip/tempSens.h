#include <max6675.h>

//inisialisasi nomer pin

int ktcSO = D7;
int ktcCS = D6;
int ktcCLK = D5;
float temp= 0;

//instance libary max6675
MAX6675 ktc(ktcCLK, ktcCS, ktcSO);

//class sensor suhu
class tempSens
{
 public:
 float getSuhu();  //method
 String getSuhuString();  //method
};

//method baca suhu
String tempSens::getSuhuString()
{
  temp= ktc.readCelsius();
  return String(temp,2);
}
float tempSens::getSuhu()
{
  temp = ktc.readCelsius();
  return temp;
}
