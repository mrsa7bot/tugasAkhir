#include "HX711.h"

#define DOUT D1 // D2 maps to GPIO4
#define CLK D2  // D1 maps to GPIO5

HX711 scale(DOUT, CLK);


class weightSens
{
  public:
  float units;
  void setCalib();
  float getWeight(float scaleWeight);
};

void weightSens::setCalib()
{
  scale.set_scale();
  scale.tare();  //Reset the scale to 0
  long zero_factor = scale.read_average(); //Get a baseline reading
}

float weightSens::getWeight(float scaleWeight)
{
  
  scale.set_scale(scaleWeight); //Adjust to this calibration factor
  units = scale.get_units(), 10;
  if (units < 0)
  {
    units = 0.00;
  }
  //Serial.print(units);
  //Serial.print(" grams"); 
  return units;
}
